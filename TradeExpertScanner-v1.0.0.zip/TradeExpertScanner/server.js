require('dotenv').config();
'use strict';
const express=require('express');
const helmet=require('helmet');
const rateLimit=require('express-rate-limit');
const path=require('path');
const {evaluate,consolidate}=require('./src/engine');
const {STRATEGIES}=require('./src/strategies');
const app=express();
const PORT=Number(process.env.PORT)||3000,MAX_SYMBOLS=Math.max(10,Math.min(30,Number(process.env.MAX_SYMBOLS)||24));
app.disable('x-powered-by');app.use(helmet({contentSecurityPolicy:{directives:{defaultSrc:["'self'"],scriptSrc:["'self'","https://s3.tradingview.com"],styleSrc:["'self'","'unsafe-inline'"],imgSrc:["'self'","data:","https:"],connectSrc:["'self'","https://fapi.binance.com","https://data-api.binance.vision"],frameSrc:["https://www.tradingview.com"]}}}));
app.use(express.json({limit:'32kb'}));app.use(rateLimit({windowMs:60000,max:60,standardHeaders:true,legacyHeaders:false}));
const allowed=(process.env.ALLOWED_ORIGINS||'').split(',').map(x=>x.trim()).filter(Boolean);
app.use((req,res,next)=>{const origin=req.headers.origin;if(origin&&allowed.length&&!allowed.includes(origin))return res.status(403).json({error:'Origin not allowed'});if(origin&&allowed.includes(origin)){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin')}next()});
app.use(express.static(path.join(__dirname,'public')));
const BASE='https://fapi.binance.com';const cache=new Map();let universeCache={at:0,data:[]};
async function api(url){const key=url,hit=cache.get(key);if(hit&&Date.now()-hit.at<20000)return hit.data;const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),12000);try{const r=await fetch(BASE+url,{signal:ctl.signal,headers:{'User-Agent':'TradeExpertScanner/1.0'}});if(!r.ok)throw new Error(`Exchange API ${r.status}`);const data=await r.json();cache.set(key,{at:Date.now(),data});return data}finally{clearTimeout(timer)}}
async function universe(){if(Date.now()-universeCache.at<60000&&universeCache.data.length)return universeCache.data;const [info,tickers]=await Promise.all([api('/fapi/v1/exchangeInfo'),api('/fapi/v1/ticker/24hr')]);const tradable=new Set(info.symbols.filter(s=>s.contractType==='PERPETUAL'&&s.quoteAsset==='USDT'&&s.status==='TRADING').map(s=>s.symbol));const list=tickers.filter(t=>tradable.has(t.symbol)&&Number(t.quoteVolume)>10000000).sort((a,b)=>Number(b.quoteVolume)-Number(a.quoteVolume)).slice(0,MAX_SYMBOLS).map(t=>({symbol:t.symbol,price:Number(t.lastPrice),change24h:Number(t.priceChangePercent),quoteVolume:Number(t.quoteVolume)}));universeCache={at:Date.now(),data:list};return list}
function parseKlines(a){return a.map(x=>({t:x[0],o:+x[1],h:+x[2],l:+x[3],c:+x[4],v:+x[5]}))}
async function mapLimit(items,limit,fn){const out=Array(items.length);let cursor=0;await Promise.all(Array.from({length:Math.min(limit,items.length)},async()=>{while(true){const i=cursor++;if(i>=items.length)return;try{out[i]=await fn(items[i],i)}catch(e){out[i]={error:e.message}}}}));return out}
app.get('/api/health',(req,res)=>res.json({ok:true,app:'Trade Expert Intelligent Scanner',version:'1.0.0',exchange:'Binance USD-M Perpetual public market data',notifications:false,autoTrading:false}));
app.get('/api/strategies',(req,res)=>res.json(STRATEGIES));
app.get('/api/universe',async(req,res)=>{try{res.json({symbols:await universe(),maxSymbols:MAX_SYMBOLS})}catch(e){res.status(502).json({error:e.message})}});
app.get('/api/scan',async(req,res)=>{
 const tfArg=String(req.query.tf||'all'),tfs=tfArg==='all'?['5m','15m','1h','4h']:[tfArg];
 if(tfs.some(t=>!['5m','15m','1h','4h'].includes(t)))return res.status(400).json({error:'Unsupported timeframe'});
 try{
  const symbols=await universe();const jobs=symbols.flatMap(s=>tfs.map(tf=>({symbol:s.symbol,tf})));
  const results=await mapLimit(jobs,8,async job=>{const k=await api(`/fapi/v1/klines?symbol=${job.symbol}&interval=${job.tf}&limit=300`);return evaluate(parseKlines(k),job.symbol,job.tf)});
  const valid=results.filter(x=>x&&!x.error);const setups=consolidate(valid);
  const performance={};for(const r of valid)for(const [id,stat] of Object.entries(r.history||{})){performance[id]??=[];performance[id].push({...stat,symbol:r.symbol,tf:r.tf})}
  const summary={symbols: symbols.length,timeframes:tfs.length,marketsScanned:valid.length,ready:setups.length,forming:0,updatedAt:new Date().toISOString(),source:'Binance USD-M Futures public API'};
  res.json({summary,setups,performance,strategies:STRATEGIES,errors:results.filter(x=>x&&x.error).slice(0,10)});
 }catch(e){res.status(502).json({error:e.message||'Market data unavailable'})}
});
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`Trade Expert Scanner running at http://localhost:${PORT}`));
